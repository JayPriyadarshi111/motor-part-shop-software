from django.contrib import admin
from .models import *

# Register your models here.

admin.site.register(Signup)
admin.site.register(Item)
# admin.site.register(Manufacturer)
# admin.site.register(Item_type)
# admin.site.register(Vehicle_Type)