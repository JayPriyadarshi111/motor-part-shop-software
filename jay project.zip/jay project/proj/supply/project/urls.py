from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('login', views.view_login, name='login'),
    path('signup', views.signup, name='signup'),
    path('do_logout', views.do_logout, name='do_logout'),
    path('list', views.list, name='list'),
    path('add', views.add, name='add'),
    path('delete/<int:id>', views.delete, name='delete'),
    path('edit/<int:id>', views.edit, name='edit'),
]