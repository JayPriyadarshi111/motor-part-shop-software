from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .forms import *

# Create your views here.
def home(request):
    if request.user.is_authenticated:
        return render(request, 'home_wilogin.html')
    else:
        return redirect('/login')

def add(request):
    if request.user.is_authenticated:
        if(request.method=="POST"):
            itype = request.POST['itype']
            vtype = request.POST['vtype']
            manufacturer = request.POST['manufacturer']
            quantity = request.POST['quantity']
            price = request.POST['price']
            item = Item(i_type=itype, v_type=vtype, manufacturer=manufacturer, quantity=quantity, price=price)
            item.save()
            return redirect('/add')
        else:
            return render(request, 'add.html')
    else:
        return redirect('/login')

def view_login(request):
    if(request.method=="POST"):
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('/')
    return render(request, 'login.html')

def signup(request):
    if(request.method=='POST'):
        username = request.POST['username']
        cnf_pwd = request.POST['cnf_password']
        pwd = request.POST['password']
        if(pwd==cnf_pwd):
            # form.save()
            # form.save()
            user = User(username=username, password=pwd)
            user.set_password(pwd)
            user.save()
            print(username)
            return redirect('/login')
        else:
            msg = "The password doesn't match"
            # form = signupForm()
            return render(request, 'signup.html', {'msg':msg})
    else:
        # form = signupForm()
        msg = ""
        return render(request, 'signup.html', {'msg':msg})
    
def do_logout(request):
    logout(request)
    return redirect('/login')

def list(request):
    if request.user.is_authenticated:
        items = Item.objects.all()
        return render(request, 'list.html', {'items':items})
    
def delete(request, id):
    item = Item.objects.filter(id=id)
    item.delete()

    return redirect('/list')

def edit(request, id):
    if(request.method=="POST"):
        item = Item.objects.get(id=id)
        item.i_type = request.POST.get('itype')
        item.v_type = request.POST.get('vtype')
        item.manufacturer = request.POST.get('manufacturer')
        item.quantity = request.POST.get('quantity')
        item.price = request.POST.get('price')
        item.save()
        return redirect('/list')
    else:
        items = Item.objects.filter(id=id)
        return render(request, 'edit.html', {'items':items})